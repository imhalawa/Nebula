# Complete SQL Mastery

[Complete SQL Mastery](https://codewithmosh.com/p/complete-sql-mastery).

[Bilibili](https://www.bilibili.com/video/BV1UE41147KC).
